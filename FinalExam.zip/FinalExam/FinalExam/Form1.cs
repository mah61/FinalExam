﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalExam
{
    public partial class Frm1 : Form
    {
        public Frm1()
        {
            InitializeComponent();
        }

        private void radioBtnCar_CheckedChanged(object sender, EventArgs e)
        {
            groupBoxOwner.Enabled = false;
            groupBoxCar.Enabled = true;

        }

        private void radioBtnOwner_CheckedChanged(object sender, EventArgs e)
        {
            groupBoxCar.Enabled = false;
            groupBoxOwner.Enabled = true;
        }

        private void Frm1_Load(object sender, EventArgs e)
        {
            cmbMake.Items.Add("Mercedes Benz");
            cmbMake.Items.Add("BMW");
            cmbMake.Items.Add("Toyota");

            cmbYear.Items.Add("2019");
            cmbYear.Items.Add("2018");
            cmbYear.Items.Add("2017");
            cmbYear.Items.Add("2016");
        }

        private void cmbMake_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbModel.Items.Clear();

            if(cmbMake.SelectedIndex == 0)
            {
                cmbModel.Items.Add("CLA");
                cmbModel.Items.Add("A-Class");
                cmbModel.Items.Add("GLC");

            }


            if (cmbMake.SelectedIndex == 1)
            {
                cmbModel.Items.Add("X4");
                cmbModel.Items.Add("X5");
                cmbModel.Items.Add("Z4");

            }

            if (cmbMake.SelectedIndex == 2)
            {
                cmbModel.Items.Add("Corolla");
                cmbModel.Items.Add("Camry");
                cmbModel.Items.Add("Tundra");

            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {

            txtFName.ResetText();
            txtLastName.ResetText();
            txtTeleph.ResetText();

            cmbMake.ResetText();
            cmbModel.ResetText();
            cmbYear.ResetText();

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtFName.Text != string.Empty && txtLastName.Text != string.Empty && txtTeleph.Text != string.Empty &&
                cmbModel.SelectedItem != null && cmbMake.SelectedItem != null && cmbYear.SelectedItem != null)
                
            {

                SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                saveFileDialog1.CheckFileExists = true;
                saveFileDialog1.CheckPathExists = true;
                saveFileDialog1.DefaultExt = "txt";
                saveFileDialog1.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
                saveFileDialog1.FilterIndex = 2;
                saveFileDialog1.RestoreDirectory = true;


                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {

                    string fileName = saveFileDialog1.FileName;
                    
                    

                    string path = @"C:\Users\1896192\Desktop\Mahnaz\exam.txt";

                    FileStream fileStream = new FileStream(path, FileMode.Append);
                    using (StreamWriter writer = new StreamWriter(fileStream))
                    {
                        writer.WriteLine("Fisrt Name: "+txtFName.Text + " " +
                                         "Last Name:  "+txtLastName.Text + " " +
                                         "Telephone:" +txtTeleph.Text + " " +
                                         "Car Make: " +cmbMake.SelectedItem.ToString() +
                                         "Car Model: " +cmbModel.SelectedItem.ToString()+
                                         "Year: " + cmbYear.SelectedItem.ToString());

                             MessageBox.Show("The Information saved in " + fileName);

                    }
                   
                }
              

            }
            else

            {
                MessageBox.Show("You should answer all questions");
            }
        }
    }
}
