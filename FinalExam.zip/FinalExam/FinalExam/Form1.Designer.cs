﻿namespace FinalExam
{
    partial class Frm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioBtnCar = new System.Windows.Forms.RadioButton();
            this.radioBtnOwner = new System.Windows.Forms.RadioButton();
            this.groupBoxCar = new System.Windows.Forms.GroupBox();
            this.groupBoxOwner = new System.Windows.Forms.GroupBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblMake = new System.Windows.Forms.Label();
            this.lblModel = new System.Windows.Forms.Label();
            this.lblYear = new System.Windows.Forms.Label();
            this.lblFname = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblTeleph = new System.Windows.Forms.Label();
            this.cmbMake = new System.Windows.Forms.ComboBox();
            this.cmbModel = new System.Windows.Forms.ComboBox();
            this.cmbYear = new System.Windows.Forms.ComboBox();
            this.txtFName = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtTeleph = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBoxCar.SuspendLayout();
            this.groupBoxOwner.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioBtnOwner);
            this.groupBox1.Controls.Add(this.radioBtnCar);
            this.groupBox1.Location = new System.Drawing.Point(30, 41);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(484, 67);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // radioBtnCar
            // 
            this.radioBtnCar.AutoSize = true;
            this.radioBtnCar.Location = new System.Drawing.Point(75, 19);
            this.radioBtnCar.Name = "radioBtnCar";
            this.radioBtnCar.Size = new System.Drawing.Size(41, 17);
            this.radioBtnCar.TabIndex = 0;
            this.radioBtnCar.TabStop = true;
            this.radioBtnCar.Text = "Car";
            this.radioBtnCar.UseVisualStyleBackColor = true;
            this.radioBtnCar.CheckedChanged += new System.EventHandler(this.radioBtnCar_CheckedChanged);
            // 
            // radioBtnOwner
            // 
            this.radioBtnOwner.AutoSize = true;
            this.radioBtnOwner.Location = new System.Drawing.Point(347, 19);
            this.radioBtnOwner.Name = "radioBtnOwner";
            this.radioBtnOwner.Size = new System.Drawing.Size(56, 17);
            this.radioBtnOwner.TabIndex = 1;
            this.radioBtnOwner.TabStop = true;
            this.radioBtnOwner.Text = "Owner";
            this.radioBtnOwner.UseVisualStyleBackColor = true;
            this.radioBtnOwner.CheckedChanged += new System.EventHandler(this.radioBtnOwner_CheckedChanged);
            // 
            // groupBoxCar
            // 
            this.groupBoxCar.Controls.Add(this.cmbYear);
            this.groupBoxCar.Controls.Add(this.cmbModel);
            this.groupBoxCar.Controls.Add(this.cmbMake);
            this.groupBoxCar.Controls.Add(this.lblYear);
            this.groupBoxCar.Controls.Add(this.lblModel);
            this.groupBoxCar.Controls.Add(this.lblMake);
            this.groupBoxCar.Location = new System.Drawing.Point(30, 139);
            this.groupBoxCar.Name = "groupBoxCar";
            this.groupBoxCar.Size = new System.Drawing.Size(227, 267);
            this.groupBoxCar.TabIndex = 1;
            this.groupBoxCar.TabStop = false;
            this.groupBoxCar.Text = "Car Registration";
            // 
            // groupBoxOwner
            // 
            this.groupBoxOwner.Controls.Add(this.txtTeleph);
            this.groupBoxOwner.Controls.Add(this.txtLastName);
            this.groupBoxOwner.Controls.Add(this.txtFName);
            this.groupBoxOwner.Controls.Add(this.lblTeleph);
            this.groupBoxOwner.Controls.Add(this.lblLastName);
            this.groupBoxOwner.Controls.Add(this.lblFname);
            this.groupBoxOwner.Location = new System.Drawing.Point(286, 139);
            this.groupBoxOwner.Name = "groupBoxOwner";
            this.groupBoxOwner.Size = new System.Drawing.Size(228, 267);
            this.groupBoxOwner.TabIndex = 2;
            this.groupBoxOwner.TabStop = false;
            this.groupBoxOwner.Text = "Owner";
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(72, 447);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(127, 46);
            this.btnReset.TabIndex = 3;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(315, 447);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(144, 46);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblMake
            // 
            this.lblMake.AutoSize = true;
            this.lblMake.Location = new System.Drawing.Point(15, 35);
            this.lblMake.Name = "lblMake";
            this.lblMake.Size = new System.Drawing.Size(34, 13);
            this.lblMake.TabIndex = 0;
            this.lblMake.Text = "Make";
            // 
            // lblModel
            // 
            this.lblModel.AutoSize = true;
            this.lblModel.Location = new System.Drawing.Point(15, 107);
            this.lblModel.Name = "lblModel";
            this.lblModel.Size = new System.Drawing.Size(36, 13);
            this.lblModel.TabIndex = 1;
            this.lblModel.Text = "Model";
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.Location = new System.Drawing.Point(18, 185);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(29, 13);
            this.lblYear.TabIndex = 2;
            this.lblYear.Text = "Year";
            // 
            // lblFname
            // 
            this.lblFname.AutoSize = true;
            this.lblFname.Location = new System.Drawing.Point(29, 35);
            this.lblFname.Name = "lblFname";
            this.lblFname.Size = new System.Drawing.Size(57, 13);
            this.lblFname.TabIndex = 0;
            this.lblFname.Text = "First Name";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(29, 107);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(58, 13);
            this.lblLastName.TabIndex = 1;
            this.lblLastName.Text = "Last Name";
            // 
            // lblTeleph
            // 
            this.lblTeleph.AutoSize = true;
            this.lblTeleph.Location = new System.Drawing.Point(29, 185);
            this.lblTeleph.Name = "lblTeleph";
            this.lblTeleph.Size = new System.Drawing.Size(58, 13);
            this.lblTeleph.TabIndex = 2;
            this.lblTeleph.Text = "Telephone";
            // 
            // cmbMake
            // 
            this.cmbMake.FormattingEnabled = true;
            this.cmbMake.Location = new System.Drawing.Point(75, 35);
            this.cmbMake.Name = "cmbMake";
            this.cmbMake.Size = new System.Drawing.Size(121, 21);
            this.cmbMake.TabIndex = 3;
            this.cmbMake.SelectedIndexChanged += new System.EventHandler(this.cmbMake_SelectedIndexChanged);
            // 
            // cmbModel
            // 
            this.cmbModel.FormattingEnabled = true;
            this.cmbModel.Location = new System.Drawing.Point(75, 107);
            this.cmbModel.Name = "cmbModel";
            this.cmbModel.Size = new System.Drawing.Size(121, 21);
            this.cmbModel.TabIndex = 4;
            // 
            // cmbYear
            // 
            this.cmbYear.FormattingEnabled = true;
            this.cmbYear.Location = new System.Drawing.Point(75, 185);
            this.cmbYear.Name = "cmbYear";
            this.cmbYear.Size = new System.Drawing.Size(121, 21);
            this.cmbYear.TabIndex = 5;
            // 
            // txtFName
            // 
            this.txtFName.Location = new System.Drawing.Point(106, 32);
            this.txtFName.Name = "txtFName";
            this.txtFName.Size = new System.Drawing.Size(100, 20);
            this.txtFName.TabIndex = 3;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(106, 107);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(100, 20);
            this.txtLastName.TabIndex = 4;
            // 
            // txtTeleph
            // 
            this.txtTeleph.Location = new System.Drawing.Point(106, 186);
            this.txtTeleph.Name = "txtTeleph";
            this.txtTeleph.Size = new System.Drawing.Size(100, 20);
            this.txtTeleph.TabIndex = 5;
            // 
            // Frm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(557, 552);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.groupBoxOwner);
            this.Controls.Add(this.groupBoxCar);
            this.Controls.Add(this.groupBox1);
            this.Name = "Frm1";
            this.Text = "Carwash System";
            this.Load += new System.EventHandler(this.Frm1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBoxCar.ResumeLayout(false);
            this.groupBoxCar.PerformLayout();
            this.groupBoxOwner.ResumeLayout(false);
            this.groupBoxOwner.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioBtnOwner;
        private System.Windows.Forms.RadioButton radioBtnCar;
        private System.Windows.Forms.GroupBox groupBoxCar;
        private System.Windows.Forms.ComboBox cmbYear;
        private System.Windows.Forms.ComboBox cmbModel;
        private System.Windows.Forms.ComboBox cmbMake;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.Label lblModel;
        private System.Windows.Forms.Label lblMake;
        private System.Windows.Forms.GroupBox groupBoxOwner;
        private System.Windows.Forms.TextBox txtTeleph;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFName;
        private System.Windows.Forms.Label lblTeleph;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblFname;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnSave;
    }
}

